# Set working directory (adjust path with your registration number folder)
setwd("C:\\Users\\mathu\\Desktop\\IT24102425")

# 1. Population mean and standard deviation
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
names(data) <- c("Weights")
attach(data)

popmn <- mean(Weights)
popsd <- sd(Weights)

cat("Population mean =", popmn, "\n")
cat("Population SD   =", popsd, "\n\n")

# 2. Draw 25 random samples of size 6 (with replacement)
samples <- c()
n <- c()

for(i in 1:25) {
  s <- sample(Weights, 6, replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n,paste('S', i))
}

colnames(samples) <- n

s.means <- apply(samples,2,mean)
s.sds   <- apply(samples, 2, sd)

cat("Sample means:\n")
print(s.means)
cat("\nSample standard deviations:\n")
print(s.sds)
cat("\n")

# 3. Mean and SD of sample means
samplemean <- mean(s.means)
samplesd   <- sd(s.means)

cat("Mean of 25 sample means =", samplemean, "\n")
cat("SD of 25 sample means   =", samplesd, "\n")

# True SD of the mean distribution
truesd <- popsd / sqrt(6)
cat("True SD =", truesd, "\n")
