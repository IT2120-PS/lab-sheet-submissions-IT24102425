# 1. Import the dataset
setwd("C:/Users/IT24102425/Desktop/IT24102425")
branch_data <- read.table("Exercise.txt", header = TRUE)

# View structure and first rows
str(branch_data)
head(branch_data)


# 3. Boxplot for sales
boxplot(branch_data$sales,
        main = "Boxplot of Sales",
        ylab = "Sales")

# 4. Five number summary & IQR for advertising
fivenum(branch_data$advertising)
IQR(branch_data$advertising)

# 5. Function to detect outliers in years
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

find_outliers(branch_data$years)
